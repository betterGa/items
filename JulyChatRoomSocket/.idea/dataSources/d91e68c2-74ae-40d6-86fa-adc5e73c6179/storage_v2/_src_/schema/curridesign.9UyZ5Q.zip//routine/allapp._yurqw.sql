create function allApp()
  returns varchar(100)
  return
(select APPname from appliance);


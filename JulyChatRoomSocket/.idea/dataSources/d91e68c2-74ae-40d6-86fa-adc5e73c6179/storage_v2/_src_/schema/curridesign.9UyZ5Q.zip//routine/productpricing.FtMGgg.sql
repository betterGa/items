create procedure productpricing()
  show databases;


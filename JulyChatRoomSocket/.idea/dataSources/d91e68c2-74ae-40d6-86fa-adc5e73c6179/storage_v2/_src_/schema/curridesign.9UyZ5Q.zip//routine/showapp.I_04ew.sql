create function showApp()
  returns varchar(30)
  return
(select APPname from appliances);


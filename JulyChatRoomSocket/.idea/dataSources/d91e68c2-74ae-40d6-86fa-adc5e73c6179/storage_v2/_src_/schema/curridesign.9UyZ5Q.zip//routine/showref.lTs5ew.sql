create function showRef()
  returns varchar(20)
  return
(select APPname from appliances where APPid='100');


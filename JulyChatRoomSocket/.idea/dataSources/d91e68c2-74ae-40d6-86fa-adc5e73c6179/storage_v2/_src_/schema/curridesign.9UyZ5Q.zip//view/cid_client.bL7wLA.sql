create view cid_client as
  select
    `curridesign`.`client`.`CLIid`   AS `CLIid`,
    `curridesign`.`client`.`CLIname` AS `CLIname`,
    `curridesign`.`client`.`CLItel`  AS `CLItel`
  from `curridesign`.`client`
  where (`curridesign`.`client`.`CLIid` = '001');


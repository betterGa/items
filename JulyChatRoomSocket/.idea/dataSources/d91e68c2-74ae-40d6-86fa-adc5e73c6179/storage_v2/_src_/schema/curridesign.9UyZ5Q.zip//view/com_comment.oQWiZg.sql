create view com_comment as
  select
    `curridesign`.`client`.`CLIid`   AS `CLIid`,
    `curridesign`.`comment`.`COMcom` AS `COMcom`,
    `curridesign`.`client`.`CLItel`  AS `CLItel`,
    `curridesign`.`comment`.`MAIid`  AS `MAIid`
  from `curridesign`.`client`
    join `curridesign`.`comment`
  where
    ((`curridesign`.`client`.`CLIid` = `curridesign`.`comment`.`CLIid`) and (`curridesign`.`client`.`CLIname` = '洪嘉佳'));

